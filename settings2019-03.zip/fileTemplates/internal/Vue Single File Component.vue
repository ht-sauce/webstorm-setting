<template>
    <div class='${COMPONENT_NAME}'></div>
</template>

<script>
export default {
    data () {
        return {}
    },
    beforeCreate () {},
    created () {},
    beforeMount () {},
    mounted () {},
    beforeUpdate () {},
    updated () {},
    activated () {},
    deactivated () {},
    beforeDestroy () {},
    destroyed () {},
    errorCaptured () {}
}
</script>

<style scoped lang="scss">

</style>
