<template>
  <div id='${NAME}'>{{msg}}</div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
//import ${NAME} from '@/components/HelloWorld.vue';

@Component
export default class ${NAME} extends Vue {
  msg: string = "${NAME}";
  data() {
    return {};
  }
  beforeCreate() {
    console.log("创建前" + this.msg);
  }
  created() {
    console.log("创建后" + this.msg);
  }
  beforeMount() {
    console.log("载入前" + this.msg);
  }
  mounted() {
    console.log("载入后" + this.msg);
    this.msg = "check update function";
  }
  beforeUpdate() {
    console.log("更新前" + this.msg);
  }
  updated() {
    console.log("更新后" + this.msg);
  }
  activated() {
    console.log("keep-alive 组件激活时调用。");
  }
  deactivated() {
    console.log("keep-alive 组件停用时调用。");
  }
  beforeDestroy() {
    console.log("销毁前" + this.msg);
  }
  destroyed() {
    console.log("销毁后" + this.msg);
  }
  errorCaptured() {
    console.log("当捕获一个来自子孙组件的错误时被调用");
  }
}
</script>
<!--scoped代表局部样式-->
<style scoped lang="scss" >
</style>